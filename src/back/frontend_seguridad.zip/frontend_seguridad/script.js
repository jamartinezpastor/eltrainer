let token = null; // Guardaremos aquí el token recibido tras el login

// Registro de usuario
document.getElementById("registro-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const datos = {
        nombre: document.getElementById("registro-nombre").value,
        email: document.getElementById("registro-email").value,
        telefono: document.getElementById("registro-telefono").value,
        contrasena: document.getElementById("registro-contrasena").value
    };

    const res = await fetch("http://localhost:8000/api/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });

    if (res.ok) {
        alert("Usuario registrado correctamente.");
    } else {
        alert("Error al registrar usuario.");
    }
});

// Login de usuario
document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const datos = {
        email: document.getElementById("login-email").value,
        contrasena: document.getElementById("login-contrasena").value
    };

    const res = await fetch("http://localhost:8000/api/usuarios/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });

    if (res.ok) {
        const respuesta = await res.json();
        token = respuesta.access_token;
        console.log("Token recibido tras login:", token);
        alert("Inicio de sesión exitoso.");
    } else {
        alert("Error en login.");
    }
});

// Crear rutina (requiere token)
document.getElementById("rutina-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!token) {
        alert("Primero debes iniciar sesión.");
        return;
    }

    const datos = {
        nombre: document.getElementById("rutina-nombre").value,
        descripcion: document.getElementById("rutina-descripcion").value
    };

    console.log("Token enviado en Authorization:", token);

    const res = await fetch("http://localhost:8000/api/rutinas", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify(datos)
    });

    if (res.ok) {
        alert("Rutina creada correctamente.");
    } else {
        alert("Error al crear rutina.");
    }
});
